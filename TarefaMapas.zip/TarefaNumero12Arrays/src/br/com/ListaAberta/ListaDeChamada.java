package br.com.ListaAberta;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ListaDeChamada {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		listaMasculina();
		listaFeminina();
		
	}

		
		private static void listaMasculina() {

	        Map<String, String> lista = new HashMap<>();
	        lista.put("Marco", "Masculino");
	        lista.put( "Lucas", "Masculino");
	        lista.put( "Antônio", "Masculino");
	        lista.put( "Alexandre", "Masculino");
	        
	        
	        System.out.println("Mapa separado por Nome e Sexo Masculino, não ordenado:");
	        lista.forEach(( nome, sexo) -> System.out.println( nome + " -- " + sexo));
		}
		
		private static void listaFeminina() {
	        System.out.println(" ---------------  X  ----------- X  ----------");
	        Map<String, String> lista2 = new HashMap<>();
	        lista2.put("Andréia", "Feminino");
	        lista2.put( "Adriana", "Feminino");
	        lista2.put( "Luana", "Feminino");
	        lista2.put( "Maria", "Feminino");
	        
	        System.out.println("Mapa separado por Nome e Sexo Feminino, não ordenado:");
	        lista2.forEach(( nome, sexo) -> System.out.println( nome + " -- " + sexo));
	        
		
	        
		}
	}

	
